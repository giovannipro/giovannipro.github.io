#!/usr/bin/env python
# -*- coding: utf-8 -*- 
# update wikipedia e scuola italiana


# -----------------------------------
# Load libraries

import csv
import pandas as pd
import sys
from datetime import date
from datetime import datetime
from dateutil.parser import parse

reload(sys)
sys.setdefaultencoding('utf-8')


# -----------------------------------
# Custom variables


folder = '/Applications/MAMP/htdocs/lavoro/giovannipro.github.io/wikipedia-scuola-italiana/assets/data/_elaboration/'


# -----------------------------------
# Main scripts


def update():
	f_prev = folder + 'voci_2021.tsv'
	f_curr = folder + '2022.tsv'
	f_upda = folder + 'voci_2022.tsv'

	with open(f_upda,'w+') as f1:

		rows = 500

		prev = pd.read_csv(f_prev, sep='\t', header=0)
		curr_0 = pd.read_csv(f_curr, sep='\t', header=0) # skiprows=0, nrows=rows 


		header = 'id_wikidata' + '\t' + \
			'article' + '\t' + \
			'subject' + '\t' + \
			'avg_pv' + '\t' + \
			'avg_pv_prev' + '\t' + \
			'size' + '\t' + \
			'size_prev' + '\t' + \
			'notes' + '\t' + \
			'notes_prev' + '\t' + \
			'images' + '\t' + \
			'images_prev' + '\t' + \
			'references' + '\t' + \
			'references_prev' + '\t' + \
			'incipit_size' + '\t' + \
			'incipit_on_size' + '\t' + \
			'incipit_prev' + '\t' + \
			'issues' + '\t' + \
			'issues_prev' + '\t' + \
			'issue_sourceNeeded' + '\t' + \
			'issue_clarify' + '\t' + \
			'discussion_size' + '\t' + \
			'discussion_prev' + '\t' + \
			'first_edit' + '\t' + \
			'days' + '\t' + \
			'all_visits' + '\t' + \
			'VdQ' + '\t' + 'vetrina' + '\t' + \
			'galleria_su_Commons' + '\t' + \
			'pagina_su_commons' + '\t' + \
			'pagina_su_wikisource'

		df = pd.DataFrame()

		# -----
		# filter

		curr_1 = curr_0[curr_0['id_wikidata'] != 'Voce inesistente']
		curr_2 = curr_1[curr_1['first_edit'] != 'ERRORE']
		curr = curr_2[curr_2['avg_pv'] != 'ERRORE']

		# -----
		# join dataset

		# c0 = curr_0 #curr[['id_wikidata','article','first_edit']] # ,'article','first_edit','avg_pv','size','notes','images','references','incipit_size','issues'

		# get subject with no space
		# prev['subject'] = prev['subject'].astype(str).str[0:3] + prev['subject'].astype(str).str[-3:]

		# p0 = prev[['id_wikidata','subject','avg_pv_0','size_0','notes_0','images_0','incipit_size_0','issues_0','discussion_size_0']]

		merged = pd.merge(curr, prev, on='id_wikidata', how='left')

		# remove duplicates
		merged.drop_duplicates(subset=['id_wikidata'], inplace=True)
		merged.dropna(inplace=True)

		merged_1 = merged #.head(rows)

		# print merged_1


		# -----
		# article main data

		df['id_wikidata'] = merged_1['id_wikidata']
		df['article'] = merged_1['article_x'].astype(str) #.str[:8]
		df['subject'] = merged_1['subject'].astype(str) #.str[:8]

		# -----
		# first edit
		try:
			df['first_edit'] = merged_1['first_edit_x']
		except (ValueError, TypeError, OverflowError):
			df['first_edit'] = '???'
			pass

		differences = []
		specific_date_str = '2022-01-01'
		specific_date = datetime.strptime(specific_date_str, '%Y-%m-%d').date()
		
		for date_str in df['first_edit']:
			try:
				date_obj = parse(date_str)
				days_difference = (specific_date - date_obj.date()).days
				differences.append(days_difference)
			except (ValueError, TypeError, OverflowError):
				differences.append(None)

		df['days'] = differences

		# -----
		# pv

		df['avg_pv'] = merged_1['avg_pv'].astype(int)
		df['avg_pv_prev'] = merged_1['avg_pv_0'].astype(int)

		try: 
			df['diff_pv'] = df['avg_pv'] - df['avg_pv_prev']
		except:
			print df['avg_pv'], df['avg_pv_prev']
			df['diff_pv'] = '???'

		# -----
		# size

		df['size'] = merged_1['size']
		df['size_prev'] = merged_1['size_0']

		# -----
		# notes
		
		df['notes'] = merged_1['notes']
		df['notes_prev'] = merged_1['notes_0']

		# -----
		# images

		df['images'] = merged_1['images']
		df['images_prev'] = merged_1['images_0']

		# -----
		# references

		df['references'] = '-'
		df['references_prev'] = '-'

		# -----
		# incipit

		df['incipit_size'] = merged_1['incipit_size']
		df['incipit_on_size'] = merged_1['incipit_size'] * 100 / merged_1['size']
		df['incipit_prev'] = merged_1['incipit_size_0']

		# -----
		# issues

		df['issues'] = merged_1['issues']
		df['issues_prev'] = merged_1['issues_0']

		default_str = ''
		# print(merged_1.columns)

		# df['issue_sourceNeeded'] = merged_1['issue_sourceNeeded_x'].fillna(default_str)
		# df['issue_clarify'] = merged_1['issue_clarify_x'].fillna(default_str)

		# -----
		# discussion_size

		df['discussion_size'] = merged_1['discussion_size']
		df['discussion_prev'] = merged_1['discussion_size_0']

		# -----
		# other data

		# df['all_visits'] = merged_1['all_visits_x'].fillna(default_str)
		# df['VdQ'] = merged_1['VdQ_x'].fillna(default_str)
		# df['galleria_su_Commons'] = merged_1['galleria_su_Commons_x'].fillna(default_str)
		# df['pagina_su_commons'] = merged_1['pagina_su_commons_x'].fillna(default_str)
		# df['pagina_su_wikisource'] = merged_1['pagina_su_wikisource_x'].fillna(default_str)

		# --------------------------
		# filters

		# df_2 = df_1[df_1['all_visits'] != 'ERRORE']

		# missing = df[df.isna().any(axis=1)]
		# missing_subject_discussion_prev = df[df['discussion_prev'].isnull()].loc[:, ['id_wikidata','article','discussion_prev']]

		# df_1 = df.dropna(axis='columns')


		missing_subject = merged_1[merged_1['subject'].isnull()].loc[:, ['id_wikidata','article','subject']]
		print(missing_subject)


		# print(df_1)


		# --------------------------
		# to do

		# 1. remove the decimals in some numbers
		# 2. aggiornare pagina 'voce con avvisi'

		# 3. verificare dati delle pagine filtrate perchè mancavano dati
		# 4. sono stati aggiunti nuovi articoli: Metalloide, Lotte in fabbrica
 

		# --------------------------


		df.to_csv(f_upda, sep='\t', index=False)
		# df_test.to_csv(f_upda, sep='\t', index=False)

		print('done')


			
# -----------------------------------
# Start scripts


update()



# -----------------------------------
# Load script

'''

python /Applications/MAMP/htdocs/lavoro/giovannipro.github.io/wikipedia-scuola-italiana/assets/data/_elaboration/_20230930_update_data.py


''' 