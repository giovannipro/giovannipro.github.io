#!/usr/bin/env python
# -*- coding: utf-8 -*- 
# update wikipedia e scuola italiana


# -----------------------------------
# Load libraries

import csv
import pandas as pd
import sys
from datetime import date
from datetime import datetime
from dateutil.parser import parse

reload(sys)
sys.setdefaultencoding('utf-8')


# -----------------------------------
# Custom variables


folder = '/Applications/MAMP/htdocs/lavoro/giovannipro.github.io/wikipedia-scuola-italiana/assets/data/_elaboration/'


# -----------------------------------
# Main scripts


def update():
	f_prev = folder + 'voci_2021.tsv'
	f_curr = folder + '2022.tsv'
	f_upda = folder + 'voci_2022.tsv'

	with open(f_upda,'w+') as f1:

		prev = pd.read_csv(f_prev, sep='\t', header=0)  # usecols =['id_wikidata','article','subject']
		curr = pd.read_csv(f_curr, sep='\t', header=0)


		header = 'id_wikidata' + '\t' + \
			'article' + '\t' + \
			'subject' + '\t' + \
			'avg_pv' + '\t' + \
			'avg_pv_prev' + '\t' + \
			'size' + '\t' + \
			'size_prev' + '\t' + \
			'notes' + '\t' + \
			'notes_prev' + '\t' + \
			'images' + '\t' + \
			'images_prev' + '\t' + \
			'references' + '\t' + \
			'references_prev' + '\t' + \
			'incipit_size' + '\t' + \
			'incipit_on_size' + '\t' + \
			'incipit_prev' + '\t' + \
			'issues' + '\t' + \
			'issues_prev' + '\t' + \
			'issue_sourceNeeded' + '\t' + \
			'issue_clarify' + '\t' + \
			'discussion_size' + '\t' + \
			'discussion_prev' + '\t' + \
			'first_edit' + '\t' + \
			'days' + '\t' + \
			'all_visits' + '\t' + \
			'VdQ' + '\t' + 'vetrina' + '\t' + \
			'galleria_su_Commons' + '\t' + \
			'pagina_su_commons' + '\t' + \
			'pagina_su_wikisource'
		# f1.write(header)

		



		# f1.write(curr.to_string())

		# create dataframe

		df = pd.DataFrame()

		df['id_wikidata'] = curr['id_wikidata']
		df['article'] = curr['article']

		#

		c0 = curr[['id_wikidata','first_edit']]
		# prev['subject_'] = prev['subject_'].str.replace(' ', '_')
		p0 = prev[['id_wikidata','subject_']]

		a0 = pd.merge(c0, p0, on='id_wikidata', how='left')
		df['subject'] = a0['subject_']
		df['first_edit'] = a0['first_edit']

		#

		# df['avg_pv'] = curr['avg_pv']

		# # # -----
		# c1 = curr[['id_wikidata', 'avg_pv']]
		# p1 = prev[['id_wikidata', 'avg_pv_0']]

		# aa = pd.merge(c1, p1, on='id_wikidata', how='left')
		# df['avg_pv_prev'] = aa['avg_pv_0']

		# # #

		# df['size'] = curr['size']

		# c2 = curr[['id_wikidata', 'size']]
		# p2 = prev[['id_wikidata', 'size_0']]

		# bb = pd.merge(c2, p2, on='id_wikidata', how='left')
		# df['size_prev'] = bb['size_0']

		# #
		# df['notes'] = curr['notes']

		# c3 = curr[['id_wikidata', 'notes']]
		# p3 = prev[['id_wikidata', 'notes_0']]

		# cc = pd.merge(c3, p3, on='id_wikidata', how='left')
		# df['notes_prev'] = cc['notes_0']


		# #

		# df['images'] = curr['images']

		# c4 = curr[['id_wikidata', 'images']]
		# p4 = prev[['id_wikidata', 'images_0']]

		# cc = pd.merge(c4, p4, on='id_wikidata', how='left')
		# df['images_prev'] = cc['images_0']

		# #

		# df['references'] = '-'
		# df['references_prev'] = '-'

		# #

		# df['incipit_size'] = curr['incipit_size']

		# df['incipit_on_size'] = curr['incipit_size'] * 100 / curr['size']

		# c5 = curr[['id_wikidata', 'incipit_size']]
		# p5 = prev[['id_wikidata', 'incipit_size_0']]

		# dd = pd.merge(c5,p5, on='id_wikidata', how='left')
		# df['incipit_prev'] = dd['incipit_size_0']

		# #

		# df['discussion_size'] = curr['discussion_size']

		# c6 = curr[['id_wikidata', 'discussion_size']]
		# p6 = prev[['id_wikidata', 'discussion_size_0']]

		# ee = pd.merge(c6, p6, on='id_wikidata', how='left')
		# df['discussion_prev'] = ee['discussion_size_0']

		# #


		# df['issues'] = curr['issues']

		# c7 = curr[['id_wikidata', 'issues']]
		# p7 = prev[['id_wikidata', 'issues_0']]

		# ff = pd.merge(c7, p7, on='id_wikidata', how='left')
		# df['issues_prev'] = ff['issues_0']


		# #

		# df['issue_sourceNeeded'] = curr['issue_sourceNeeded']
		# df['issue_clarify'] = curr['issue_clarify']

		# #

		# df['first_edit'] = curr['first_edit']

		# differences = []
		# specific_date_str = '2022-01-01'
		# specific_date = datetime.strptime(specific_date_str, '%Y-%m-%d').date()
		
		# for date_str in curr['first_edit']:
		# 	try:
		# 		date_obj = parse(date_str)
		# 		days_difference = (specific_date - date_obj.date()).days
		# 		differences.append(days_difference)
		# 	except (ValueError, TypeError, OverflowError):
		# 		differences.append(None)

		# df['days'] = differences

		# #

		# df['all_visits'] = curr['all_visits']

		# df['VdQ'] = curr['VdQ']

		# df['galleria_su_Commons'] = curr['galleria_su_Commons']

		# df['pagina_su_commons'] = curr['pagina_su_commons']

		# df['pagina_su_wikisource'] = curr['pagina_su_wikisource']


		# --------------------------
		# filters

		df_1 = df[df['id_wikidata'] != 'Voce inesistente']
		df_2 = df_1[df_1['all_visits'] != 'ERRORE']

		# missing = df_2[df_2.isna().any(axis=1)]
		print(df_2)


		# --------------------------
		# to do

		# 1. remove the decimals in some numbers
		# 2. aggiornare pagina 'voce con avvisi'
		# 3. alcune voci mancano di dati: Allergia, Allevamento
		# 4. sono stati aggiunti nuovi articoli: Metalloide, Lotte in fabbrica
 

		# --------------------------


		df_2.to_csv(f_upda, sep='\t', index=False)
		# df_test.to_csv(f_upda, sep='\t', index=False)

		print('done')


			
# -----------------------------------
# Start scripts


update()



# -----------------------------------
# Load script

'''

python /Applications/MAMP/htdocs/lavoro/giovannipro.github.io/wikipedia-scuola-italiana/assets/data/_elaboration/update_data.py


''' 